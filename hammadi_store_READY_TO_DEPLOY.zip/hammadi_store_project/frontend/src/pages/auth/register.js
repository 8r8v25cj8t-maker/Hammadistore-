import {useState} from 'react';
import axios from 'axios';
import Router from 'next/router';
export default function Register(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const submit = async (e)=>{ e.preventDefault(); try{ await axios.post(process.env.NEXT_PUBLIC_API_URL + '/api/auth/register',{name,email,password}); alert('Registered'); Router.push('/auth/login'); }catch(err){ alert(err.response?.data?.message || 'Error'); }}
  return (<div className="container"><h2>تسجيل حساب</h2><form onSubmit={submit}><input placeholder="الاسم" value={name} onChange={e=>setName(e.target.value)} /><input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><button>تسجيل</button></form></div>)
}
