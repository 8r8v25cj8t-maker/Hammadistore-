import {useState} from 'react';
import axios from 'axios';
import Router from 'next/router';
export default function Login(){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const submit = async (e)=>{ e.preventDefault(); try{ const res = await axios.post(process.env.NEXT_PUBLIC_API_URL + '/api/auth/login',{email,password}); localStorage.setItem('token', res.data.token); Router.push('/dashboard'); }catch(err){ alert(err.response?.data?.message || 'Error'); }}
  return (<div className="container"><h2>تسجيل الدخول</h2><form onSubmit={submit}><input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><button>دخول</button></form></div>)
}
