import {useEffect, useState} from 'react';
import axios from 'axios';
export default function Dashboard(){
  const [user,setUser]=useState(null);
  useEffect(()=>{
    const token = localStorage.getItem('token');
    if(!token) return;
    axios.get(process.env.NEXT_PUBLIC_API_URL + '/api/auth/me', { headers: { Authorization: 'Bearer ' + token } }).then(r=>setUser(r.data)).catch(()=>{});
  },[]);
  return (<div className="container"><h2>لوحة الحساب</h2>{user? <div><p>الاسم: {user.name}</p><p>الرصيد: {user.balance} د.ل</p><p>إجمالي الإنفاق: {user.total_spent} د.ل</p></div> : <p>جاري التحميل...</p>}</div>)
}
