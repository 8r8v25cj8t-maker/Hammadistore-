import {useState} from 'react';
import axios from 'axios';
export default function TopUp(){
  const [provider,setProvider]=useState('libyana');
  const [fromPhone,setFromPhone]=useState('');
  const [amount,setAmount]=useState('');
  const submit = async (e)=>{ e.preventDefault(); const token = localStorage.getItem('token'); if(!token){ alert('Login first'); return; } try{ await axios.post(process.env.NEXT_PUBLIC_API_URL + '/api/topup/create',{provider,from_phone:fromPhone,amount},{ headers: { Authorization: 'Bearer ' + token }}); alert('بانتظار التأكيد من الإدارة'); }catch(err){ alert(err.response?.data?.message || 'Error'); }}
  return (<div className="container"><h2>شحن الرصيد</h2><form onSubmit={submit}><label>الشركة</label><select value={provider} onChange={e=>setProvider(e.target.value)}><option value="libyana">ليبيانا</option><option value="madar">مدار</option></select><label>رقم الهاتف المحول منه</label><input value={fromPhone} onChange={e=>setFromPhone(e.target.value)} /><label>المبلغ</label><input value={amount} onChange={e=>setAmount(e.target.value)} /><button>إرسال طلب الشحن</button></form></div>)
}
