import {useState, useEffect} from 'react';
import axios from 'axios';
export default function NewOrder(){
  const [categories,setCategories]=useState(['إنستغرام','تيك توك','يوتيوب','سناب شات','تيلغرام','عروض حمادي']);
  const [category,setCategory]=useState('عروض حمادي');
  const [services,setServices]=useState([]);
  const [serviceId,setServiceId]=useState(null);
  const [link,setLink]=useState('');
  const [qty,setQty]=useState(100);
  const [price,setPrice]=useState(0);

  useEffect(()=>{ fetchServices(); },[category]);
  async function fetchServices(){ const res = await axios.get(process.env.NEXT_PUBLIC_API_URL + '/api/services?category=' + encodeURIComponent(category)); setServices(res.data); if(res.data.length){ setServiceId(res.data[0].id); }}
  useEffect(()=>{ const s = services.find(x=>x.id==serviceId); if(s){ setPrice((s.price_per_1000 * qty)/1000); }},[serviceId,qty,services]);

  async function submit(e){ e.preventDefault(); const token = localStorage.getItem('token'); if(!token){ alert('Login first'); return; } try{ const res = await axios.post(process.env.NEXT_PUBLIC_API_URL + '/api/orders/create',{service_id:serviceId,link,qty},{ headers: { Authorization: 'Bearer ' + token }}); alert('Order created: ' + res.data.orderId); }catch(err){ alert(err.response?.data?.message || 'Error'); }}

  return (<div className="container"> <h2>طلب جديد</h2>
    <form onSubmit={submit}>
      <label>الفئة</label>
      <select value={category} onChange={e=>setCategory(e.target.value)}>{categories.map(c=> <option key={c}>{c}</option>)}</select>
      <label>الخدمة</label>
      <select value={serviceId} onChange={e=>setServiceId(e.target.value)}>{services.map(s=> <option key={s.id} value={s.id}>{s.title} - {s.price_per_1000} د.ل/1000</option>)}</select>
      <label>الرابط</label>
      <input value={link} onChange={e=>setLink(e.target.value)} />
      <label>الكمية</label>
      <input type="number" value={qty} onChange={e=>setQty(e.target.value)} />
      <p>السعر النهائي: {price.toFixed(2)} د.ل</p>
      <button>إرسال الطلب</button>
    </form>
  </div>)
}
