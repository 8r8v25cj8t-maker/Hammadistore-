import Link from 'next/link'
export default function Home(){
  return (
    <div className="container">
      <h1>حمّادي ستور | Hammadi Store</h1>
      <p>مرحبًا بك — اللغة الافتراضية: العربية</p>
      <div style={{display:'flex',gap:10}}>
        <Link href="/auth/login"><a>تسجيل الدخول</a></Link>
        <Link href="/auth/register"><a>تسجيل حساب</a></Link>
      </div>
    </div>
  )
}
