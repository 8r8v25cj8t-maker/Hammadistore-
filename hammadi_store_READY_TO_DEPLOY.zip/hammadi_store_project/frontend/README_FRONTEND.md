# Frontend - Hammadi Store

## Setup

1. Install dependencies
```bash
cd frontend
npm install
```

2. Create `.env.local` file (copy from `.env.local.example`) and set `NEXT_PUBLIC_API_URL` to your backend URL (e.g. http://localhost:4000)

3. Run dev server:
```bash
npm run dev
```

Open http://localhost:3000
