# Backend - Hammadi Store

## Setup

1. Install dependencies
```bash
cd backend
npm install
```

2. Create `.env` file (copy from `.env.example`) and set your DB credentials and JWT secret.

3. Initialize database: import `hammadi_store.sql` into your MySQL server.

4. Run in development:
```bash
npm run dev
```

This starts the backend on `http://localhost:4000` by default.
