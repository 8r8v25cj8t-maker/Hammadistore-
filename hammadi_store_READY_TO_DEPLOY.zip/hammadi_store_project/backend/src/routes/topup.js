const express = require('express');
const router = express.Router();
const authJwt = require('../middlewares/authJwt');
const db = require('../db');

router.post('/create', authJwt, async (req,res)=>{
  try{
    const {provider, from_phone, amount} = req.body;
    if(!['libyana','madar'].includes(provider)) return res.status(400).json({message:'Invalid provider'});
    const userId = req.user.id;
    await db.query('INSERT INTO topups (user_id,provider,from_phone,amount,status) VALUES (?,?,?,?,?)',[userId,provider,from_phone,amount,'pending']);
    res.json({message:'pending_admin_confirmation'});
  }catch(err){ console.error(err); res.status(500).json({message:'Server error'}); }
});

module.exports = router;