const express = require('express');
const router = express.Router();
const db = require('../db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

router.post('/register', async (req,res)=>{
  const {name,email,password,phone} = req.body;
  if(!email || !password) return res.status(400).json({message:'Email and password required'});
  const [exists] = await db.query('SELECT id FROM users WHERE email=?',[email]);
  if(exists.length) return res.status(400).json({message:'Email exists'});
  const hashed = await bcrypt.hash(password,10);
  await db.query('INSERT INTO users (name,email,phone,password_hash) VALUES (?,?,?,?)',[name,email,phone,hashed]);
  res.json({message:'ok'});
});

router.post('/login', async (req,res)=>{
  const {email,password} = req.body;
  const [rows] = await db.query('SELECT * FROM users WHERE email=?',[email]);
  if(!rows.length) return res.status(400).json({message:'Invalid'});
  const user = rows[0];
  const match = await bcrypt.compare(password, user.password_hash);
  if(!match) return res.status(400).json({message:'Invalid'});
  const token = jwt.sign({id:user.id,role:user.role,email:user.email}, process.env.JWT_SECRET, {expiresIn:'7d'});
  res.json({token, user:{id:user.id,name:user.name,email:user.email,balance:user.balance,total_spent:user.total_spent,role:user.role}});
});

module.exports = router;