const express = require('express');
const router = express.Router();
const authJwt = require('../middlewares/authJwt');
const db = require('../db');

router.post('/create', authJwt, async (req,res)=>{
  try{
    const {service_id, link, qty} = req.body;
    const userId = req.user.id;
    const [serviceRows] = await db.query('SELECT * FROM services WHERE id=?',[service_id]);
    if(!serviceRows.length) return res.status(400).json({message:'Service not found'});
    const service = serviceRows[0];
    const price = (parseFloat(service.price_per_1000) * parseInt(qty,10)) / 1000.0;
    const [userRows] = await db.query('SELECT balance FROM users WHERE id=?',[userId]);
    if(!userRows.length) return res.status(400).json({message:'User not found'});
    const balance = parseFloat(userRows[0].balance);
    if(balance < price) return res.status(400).json({message:'Insufficient balance'});
    await db.query('UPDATE users SET balance = balance - ?, total_spent = total_spent + ? WHERE id=?',[price,price,userId]);
    const [result] = await db.query('INSERT INTO orders (user_id,service_id,link,qty,price,status) VALUES (?,?,?,?,?,?)',[userId,service_id,link,qty,price,'in_progress']);
    const orderId = result.insertId;
    // For starter, no actual provider dispatch. Save order and return.
    res.json({message:'order_created', orderId});
  }catch(err){
    console.error(err);
    res.status(500).json({message:'Server error'});
  }
});

// get user's orders
router.get('/', authJwt, async (req,res)=>{
  const userId = req.user.id;
  const [rows] = await db.query('SELECT o.*, s.title as service_title FROM orders o LEFT JOIN services s ON o.service_id=s.id WHERE o.user_id=? ORDER BY o.created_at DESC',[userId]);
  res.json(rows);
});

module.exports = router;