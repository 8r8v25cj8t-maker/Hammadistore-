const express = require('express');
const router = express.Router();
const authJwt = require('../middlewares/authJwt');
const db = require('../db');

// middleware: check admin role
const isAdmin = (req,res,next)=>{ if(req.user.role !== 'admin') return res.status(403).json({message:'Forbidden'}); next(); };

router.use(authJwt);
router.use(isAdmin);

// list users
router.get('/users', async (req,res)=>{
  const [rows] = await db.query('SELECT id,name,email,phone,balance,total_spent,role,created_at FROM users');
  res.json(rows);
});

// list orders
router.get('/orders', async (req,res)=>{
  const [rows] = await db.query('SELECT o.*, u.email as user_email, s.title as service_title FROM orders o LEFT JOIN users u ON o.user_id=u.id LEFT JOIN services s ON o.service_id=s.id ORDER BY o.created_at DESC');
  res.json(rows);
});

// change order status or cancel
router.post('/order/:id/status', async (req,res)=>{
  const id = req.params.id;
  const {status} = req.body;
  await db.query('UPDATE orders SET status=? WHERE id=?',[status,id]);
  res.json({message:'ok'});
});

// confirm topup
router.post('/topup/:id/confirm', async (req,res)=>{
  const id = req.params.id;
  const [rows] = await db.query('SELECT * FROM topups WHERE id=?',[id]);
  if(!rows.length) return res.status(400).json({message:'Not found'});
  const t = rows[0];
  await db.query('UPDATE topups SET status=? WHERE id=?',['confirmed',id]);
  await db.query('UPDATE users SET balance = balance + ? WHERE id=?',[t.amount, t.user_id]);
  res.json({message:'ok'});
});

// add or subtract balance manually
router.post('/users/:id/adjust-balance', async (req,res)=>{
  const id = req.params.id;
  const {amount, note} = req.body; // amount can be negative
  await db.query('UPDATE users SET balance = balance + ? WHERE id=?',[amount, id]);
  res.json({message:'ok'});
});

module.exports = router;