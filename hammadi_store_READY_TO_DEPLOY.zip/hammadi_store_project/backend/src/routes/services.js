const express = require('express');
const router = express.Router();
const db = require('../db');

// list services, optional filter by category
router.get('/', async (req,res)=>{
  const category = req.query.category;
  let q = 'SELECT * FROM services';
  const params = [];
  if(category){ q += ' WHERE category = ?'; params.push(category); }
  const [rows] = await db.query(q, params);
  res.json(rows);
});

module.exports = router;