// Placeholder SMM provider manager.
// In production this module would call external provider APIs, manage mappings, fallbacks, and update orders.
module.exports = {
  async createOrder(orderId, service, link, qty){
    // For starter return a fake provider id.
    return {provider_order_id: 'PROV-' + orderId};
  }
};