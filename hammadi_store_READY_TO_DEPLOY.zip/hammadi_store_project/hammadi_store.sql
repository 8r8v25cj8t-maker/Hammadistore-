-- Database schema for Hammadi Store
CREATE DATABASE IF NOT EXISTS hammadi_store CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE hammadi_store;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) DEFAULT '',
  email VARCHAR(200) UNIQUE,
  phone VARCHAR(50),
  password_hash VARCHAR(255),
  balance DECIMAL(12,2) DEFAULT 0.00,
  total_spent DECIMAL(12,2) DEFAULT 0.00,
  role ENUM('user','admin') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  provider_service_id VARCHAR(100) DEFAULT NULL,
  category VARCHAR(100),
  title VARCHAR(255),
  price_per_1000 DECIMAL(10,2),
  min_qty INT DEFAULT 1,
  max_qty INT DEFAULT 100000,
  provider_id INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  service_id INT,
  link TEXT,
  qty INT,
  price DECIMAL(12,2),
  currency VARCHAR(10) DEFAULT 'LYD',
  status ENUM('pending','in_progress','completed','cancelled') DEFAULT 'pending',
  provider_order_id VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS topups (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  provider ENUM('libyana','madar'),
  from_phone VARCHAR(50),
  amount DECIMAL(12,2),
  status ENUM('pending','confirmed','rejected') DEFAULT 'pending',
  admin_note TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS api_providers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150),
  api_url TEXT,
  api_key TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS provider_mappings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  service_id INT,
  provider_id INT,
  provider_service_id VARCHAR(100),
  price_override DECIMAL(10,2) DEFAULT NULL,
  FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
  FOREIGN KEY (provider_id) REFERENCES api_providers(id) ON DELETE CASCADE
);

-- Insert initial "عروض حمادي" services
INSERT INTO services (category, title, price_per_1000, min_qty, max_qty) VALUES
('عروض حمادي','لايكات فيديو تيك توك الاسرع بجوده عالية جدا - بدون ضمان', 2.00, 100, 100000),
('عروض حمادي','متابعين تيك توك جوده وسرعة عاليه جدا', 13.00, 100, 100000),
('عروض حمادي','متابعين انستجرام بجوده وسرعه عالية جدا - بدون ضمان ++', 14.00, 100, 100000),
('عروض حمادي','متابعين فيسبوك علي جميع الروابط سريع - بجوده عالية', 5.00, 100, 100000);
