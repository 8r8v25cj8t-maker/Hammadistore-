# Hammadi Store - Fullstack Starter

This archive contains a starter full-stack application for **حمّادي ستور | Hammadi Store**.

It includes:
- backend: Express (Node.js)
- frontend: Next.js minimal scaffold
- SQL: MySQL schema + initial services for "عروض حمادي"

**Important:** This is a starter package. You must run `npm install` in both `backend` and `frontend` and configure environment variables in `.env` files before running.

See instructions in README_BACKEND.md and README_FRONTEND.md
