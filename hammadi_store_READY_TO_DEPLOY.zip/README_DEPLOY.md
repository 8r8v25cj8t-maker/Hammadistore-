# نشر حمّادي ستور على VPS (جاهز)
1) ثبّت Node.js 18+ و MySQL و Nginx.
2) أنشئ قاعدة بيانات:
   mysql -u root -p < hammadi_store.sql
3) عدّل backend/.env بالقيم الصحيحة.
4) شغّل:
   cd backend
   npm install
   npm run start
5) شغّل الواجهة:
   cd frontend
   npm install
   npm run build
   npm run start
6) اربط Nginx بـ 3000 و 4000.
7) فعّل SSL عبر certbot.

ملاحظة: رسالة 'تحقق من الأمان' تظهر لأنك تعمل بدون HTTPS (localhost). ستختفي بعد SSL.
