-- حساب الأدمن الجاهز
INSERT INTO users (name,email,password_hash,role) VALUES (
'Admin','mk1707465@gmail.com','$2b$12$7vwXAMFsbKy2GDcrTXRqNOLHfHPZf8bEz./FqIPp6sExIPZ/G7T.a','admin'
);